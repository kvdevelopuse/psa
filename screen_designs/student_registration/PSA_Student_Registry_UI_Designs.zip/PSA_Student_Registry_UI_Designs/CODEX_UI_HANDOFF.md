# UI handoff for Codex: PSA Student Registry (Phase 1)

Use this file together with `README.md` (screen index and PRD mapping) and the PNGs in this folder.
Stack (PRD NFR-02): **React + Vite** front end, **FastAPI** back end, **PostgreSQL**.

## How to use the images

1. Open the PNG for the screen you are building before writing its component. Match layout, spacing, copy and states.
2. Build the shared shell once (`C1` sidebar, `C2` top bar, `C3` profile header) and reuse it on every page.
3. Load colours from `tokens.css`. Don't hard-code hex values in components.
4. Treat the sample data in the images as fixtures only. Real data comes from the API.
5. If an image and the PRD disagree, follow the PRD and flag the difference.

## Suggested front-end structure

```
src/
  styles/tokens.css            ← copy from this folder
  layout/AppShell.tsx          ← Sidebar + TopBar + <Outlet/>       (C1, C2)
  components/
    SectionBand.tsx            ← red letter tab + blue band          (08, 00)
    PhotoFrame.tsx             ← red-outlined avatar/photo           (11, 00)
    RegNoChip.tsx  StatusPill.tsx  KindTag.tsx  Field.tsx  Modal.tsx
  pages/
    Login.tsx                  ← 01
    Setup/                     ← 02 (5-step wizard)
    DatabaseError.tsx          ← 03
    Dashboard.tsx              ← 05
    Students/List.tsx          ← 06 (+ D4 export modal)
    Students/RegisterForm.tsx  ← 08, 09 (+ D1, D2)
    Students/EditForm.tsx      ← 10 (+ D2)
    Students/Profile/          ← 11 Details, 12 Documents, 13 History (+ D3)
    History.tsx                ← 07
    Import/                    ← 14 Map, 15 Preview, 16 Done
    Settings.tsx               ← 17 (+ D6)
    Backup.tsx                 ← 18 (+ D5)
```

Routes are listed in `README.md`. The installer screen (04) belongs to the Windows installer, not the React app.

## Behaviour shown in the designs

- **Required fields** (08, 09): full name, gender, date of birth, nationality, Emirates ID, passport, and at least one valid phone. On a failed save, show an error summary at the top, inline messages, red field outlines, and move focus to the first error. No registration number is issued.
- **Emirates ID** (08, D1): auto-format to `784-YYYY-NNNNNNN-N`. A match against any record, active or inactive, opens D1 instead of saving. For an inactive match, D1 offers *Reactivate and open*.
- **Registration number** (08, 10, 17): shown greyed as "issued when you save" on new forms and locked on edit. Numbers are never reused.
- **Dates:** always display `DD-MMM-YYYY`. Show age next to date of birth (proposed).
- **Edit** (10): mark changed fields and show the old value. Show the folder rename `PSA-0001-Old_Name → PSA-0001-New_Name` when the name changes.
- **Documents** (12): JPG, PNG or PDF, up to the configured limit (10 MB). Replace creates `_v2`, `_v3`… and earlier versions stay downloadable.
- **Import** (15): duplicate Emirates IDs, number conflicts or a prefix mismatch block the whole import, so the *Back up & import* button is disabled. Offer an `.xlsx` error report.
- **Backup** (05, 18): flag backups older than 30 days in red, show the same-drive warning when needed, and mark incomplete backups *Not restorable*. Restore (D5) needs the acknowledgement checkbox.
- **Dialogs:** dim the page behind the dialog. Every dialog has a visible Cancel or Close. Use the red primary button only for destructive actions (D3, D5).

## Accessibility rules used throughout

- Real `<button>`, `<a>`, `<input>` and `<label>` elements. Icon-only buttons get `aria-label`.
- Controls are at least 44 px tall.
- Text meets 4.5:1 contrast. Status is never shown by colour alone (pills carry text).
- Status tabs use `role="tablist"`. Error summaries use `role="alert"`.

## Fonts

```html
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&family=Barlow+Condensed:wght@600;700;800&display=swap" rel="stylesheet">
```

The app runs offline on one PC (NFR-01), so self-host these fonts (for example with `@fontsource/barlow` and `@fontsource/barlow-condensed`) instead of loading them from Google at runtime.
