# PSA Student Registry — UI designs (Phase 1)

Design references for building the Phase 1 app described in *PSA Student Registration PRD v0.1*.
Every PNG is rendered at 2× (retina). Desktop pages are designed at 1440 px wide; pages longer than the screen are captured in full.

**Building in Codex?** Start with `CODEX_UI_HANDOFF.md`, and copy `tokens.css` into `src/styles/`.

Sample data: 5 fictional students (PSA-0001 to PSA-0005). Names, Emirates IDs, passports and phone numbers are invented.

## File naming

`<NN>_<Area>_<Screen>_<State>.png`

- `NN`: screen number, in the order a user meets them
- `D1–D6`: dialogs (modal overlays shown on top of a page)
- `00`, `C1–C3`: design system and shared components

## Index

| File | Screen | Suggested route | PRD |
| --- | --- | --- | --- |
| **01_Access-and-Setup** | | | |
| 01_Login_SignIn | Administrator sign-in | `/login` | U-01 |
| 02_FirstRun_Setup_Step3_StorageFolders | First-run wizard, step 3 of 5 (academy → database → folders → numbering → ready) | `/setup` | R-21, R-24 |
| 03_Error_DatabaseConnectionFailed | Shown when PostgreSQL can't be reached after the automatic restart attempt | `/error/database` | R-16, R-26 |
| 04_Installer_UpgradeExistingInstall | Windows installer when an existing installation is found | installer | R-25 |
| **02_Dashboard-Students-History** | | | |
| 05_Dashboard_Home | Two count cards, backup health, recent activity, quick actions | `/` | R-14, R-22 |
| 06_Students_List_SearchFilterPaginate | Student list: status tabs, search, export, pagination | `/students` | R-12, R-20 |
| 07_History_GlobalAuditTrail | All changes across students, newest first, grouped by day | `/history` | R-15 |
| **03_Registration-and-Edit** | | | |
| 08_Registration_NewStudent_Form | Single-page form, sections A–F, documents, office use | `/students/new` | R-01 to R-06, R-11 |
| 09_Registration_ValidationErrors | Save blocked: error summary, inline errors, focus on first error | `/students/new` | R-02 to R-05 |
| 10_Student_Edit_Form | Edit with changed-field markers, locked registration number, folder rename notice | `/students/:id/edit` | R-08 |
| **04_Student-Profile** | | | |
| 11_Profile_Tab1_Details | Profile header plus all saved fields | `/students/:id` | R-13 |
| 12_Profile_Tab2_Documents_Versions | Photo, passport and Emirates ID files with version history and preview | `/students/:id/documents` | R-11 |
| 13_Profile_Tab3_StudentHistory | Change history for this student only | `/students/:id/history` | R-15 |
| **05_Excel-Import** | | | |
| 14_Import_Step2_MapColumns | Map workbook columns to student fields | `/import` | R-17 |
| 15_Import_Step3_Preview_BlockedByConflict | Row checks; a duplicate Emirates ID blocks the whole import | `/import` | R-18, R-19 |
| 16_Import_Step4_Complete | Result after the safety backup and import | `/import` | R-17, R-18 |
| **06_Settings-and-Backup** | | | |
| 17_Settings_AllSections | Academy, security, numbering row, storage, system | `/settings` | R-09, R-10, R-21 |
| 18_Backup_and_Restore | Backup status, locations, backup list with restore | `/backup` | R-22, R-23 |
| **07_Dialogs** | | | |
| D1_Dialog_DuplicateEmiratesID_Reactivate | On save when the Emirates ID already exists (here, an inactive student) | over 08 | R-03, R-07 |
| D2_Dialog_UnsavedChanges_LeaveConfirm | Leaving a form with unsaved changes | over 08 / 10 | R-01 |
| D3_Dialog_MarkStudentInactive | Confirm status change | over 11 | R-07 |
| D4_Dialog_ExportStudents_ExcelPDF | Format and optional fields for export | over 06 | R-20 |
| D5_Dialog_RestoreBackup_OverwriteWarning | Restore confirmation with acknowledgement | over 18 | R-23 |
| D6_Dialog_BulkRenumber_Preview | Saving a new prefix/separator with "Update existing numbers" ticked | over 17 | R-10 |
| **08_Design-System** | | | |
| 00_Foundations_Colours_Type_Controls | Palette, type scale, signature shapes, buttons, fields, status pills | — | — |
| C1_Component_Sidebar_Navigation | Left navigation, 248 px, active state shown on Dashboard | shared | — |
| C2_Component_TopBar | Page title, global search, New registration button | shared | — |
| C3_Component_ProfileHeader | Student header with photo frame, status, actions and tabs | shared | R-13 |

## Design tokens

| Token | Value | Use |
| --- | --- | --- |
| `--psa-blue` | `#2A3A9E` | Brand, primary buttons, section bands |
| `--psa-navy` | `#1B2466` | Sidebar, dark panels |
| `--psa-red` | `#D7262E` | Accent, create/destructive actions, errors, required asterisks |
| `--ink` | `#15172B` | Body text |
| `--slate` | `#5E6280` | Secondary text, table headers |
| `--line` | `#E3E4EC` | Card outlines and dividers |
| `--field` | `#ECEAF2` | Input background (from the paper form's fill-in boxes) |
| `--blue-tint` | `#E9ECFA` | Registration-number chips, selected options |
| `--canvas` | `#F3F3F7` | Page background |
| `--success` | `#17663A` on `#E3F4EA` | Active pill, verified states |
| `--error` | `#A3141B` on `#FBE9EA` | Inline errors, blocking conflicts |
| `--warning` | `#6B3A00` on `#FFF4E0` | Default-password and same-drive warnings |

**Type:** the designs specify **Barlow** (body, 400–700) and **Barlow Condensed** (headings, numbers, section bands; 700–800, uppercase, letter-spaced). Both are free on Google Fonts. These PNGs were rendered offline, so Inter and TeX Gyre Heros Cn stand in for them; the live canvas shows the intended fonts.

**Shape and spacing:** cards 14 px radius, buttons 8 px, inputs 6 px; 44–48 px minimum control height; 24–32 px page gutters; 4 / 8 / 12 / 16 / 24 / 32 spacing steps.

**Signature elements:** red lettered tab plus slanted blue band for form sections; slanted red and white stripes for decoration; red-outlined photo frame for student avatars; `PSA-0001` chips in condensed type.

## Decisions to confirm (open in the PRD)

- Student list opens on **Active**. Screen 06 shows the **All** tab so all five sample students are visible.
- Gender offers Male / Female, as on the paper form (Q-05).
- Export scope (all filtered rows vs. current page) is still open (Q-07). D4 exports the whole filter.
- Recently Registered counts students registered this calendar month, active or not (Q-04).
- Rows per page are 20 / 50 / 100 (Q-06, proposed).
